package com.university.bookstore.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import com.university.bookstore.api.BookstoreAPI;
import com.university.bookstore.model.Book;

/**
 * <p> Implementation of the BookstoreAPI interface using an ArrayList.
 * Provides CRUD, search, analytics, and export operations on the bookstore inventory.
 * All collection returns are defensive copies to maintain encapsulation.
 * <p>This class ensures that ISBNs are unique within the inventory.</p>
 */

public class BookstoreArrayList implements BookstoreAPI {
    private final List<Book> inventory;

    /**
     * Constructs an empty bookstore.
     */
    public BookstoreArrayList() {
        this.inventory = new ArrayList<>();
    }

    /**
     * Constructs a bookstore with initial books.
     */
    public BookstoreArrayList(Collection<Book> initialBooks) {
        this.inventory = new ArrayList<>();
        if (initialBooks != null) {
            for (Book book : initialBooks) {
                add(book);
            }
        }
    }

    // Core CRUD operations
    @Override
    public boolean add(Book book) {
        // Check if book is null
        if (book == null) {
            throw new IllegalArgumentException("book cannot be null");
        }

        // Check for duplicate ISBN
        for (Book exists : inventory) {
            if (exists.getIsbn().equals(book.getIsbn())) {
                return false;
            }
        }
        return inventory.add(book);
    }

    @Override
    public boolean removeByIsbn(String isbn) {
        if (isbn == null) {
            return false;
        }
        inventory.removeIf(book -> book.getIsbn().equals(isbn));
        return true;
    }

    @Override
    public Book findByIsbn(String isbn) {
        if (isbn == null) {
            return null;
        }

        for (Book book : inventory) {
            if (book.getIsbn().equals(isbn)) {
                return book;
            }
        }
        return null;
    }

    // Search operations
    @Override
    public List<Book> findByTitle(String titleQuery) {
        if (titleQuery == null || titleQuery.trim().isEmpty()) {
            return Collections.emptyList();
        }

        String query = titleQuery.toLowerCase().trim();
        return inventory.stream().filter(book -> book.getTitle().toLowerCase().contains(query)).collect(Collectors.toList());
    }

    @Override
    public List<Book> findByAuthor(String authorQuery) {
        if (authorQuery == null || authorQuery.trim().isEmpty()) {
            return Collections.emptyList();
        }
        String query = authorQuery.toLowerCase().trim();
        return inventory.stream().filter(book -> book.getAuthor().toLowerCase().contains(query)).collect(Collectors.toList());
    }

    @Override
    public List<Book> findByPriceRange(double minPrice, double maxPrice) {
        if (minPrice < 0 || maxPrice < 0) {
            throw new IllegalArgumentException("Prices cannot be negative");
        }

        if (maxPrice < minPrice) {
            throw new IllegalArgumentException("Minimum price cannot be greater than maximum price");
        }

        return inventory.stream().filter(book -> book.getPrice() >= minPrice && book.getPrice() <= maxPrice).collect(Collectors.toList());
    }

    @Override
    public List<Book> findByYear(int year) {
        return inventory.stream().filter(book -> book.getYear() == year).collect(Collectors.toList());
    }

    // Analytics operations
    @Override
    public int size() {
        return inventory.size();
    }

    @Override
    public double inventoryValue() {
        return inventory.stream().mapToDouble(Book::getPrice).sum();
    }

    @Override
    public Book getMostExpensive() {
        return inventory.stream().max(Comparator.comparingDouble(Book::getPrice)).orElse(null);
    }

    @Override
    public Book getMostRecent() {
        return inventory.stream().max(Comparator.comparingDouble(Book::getYear)).orElse(null);
    }

    // Export operations
    @Override
    public Book[] snapshotArray() {
        return inventory.toArray(new Book[0]);
    }

    @Override
    public List<Book> getAllBooks() {
        return new ArrayList<>(inventory);
    }
}