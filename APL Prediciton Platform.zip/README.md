# Bookstore Management System - Lab 1 Solution
## Contacts
221493267, neha2@my.york.ca, Neharika, Boddakayala

221412374, shlok64@my.yorku.ca, Shlok, Desai

Student 03 ID, Student 01 Email, Student 01 First Name, Student 01 Last Name

218740654, stefan07@my.yorku.ca, Stefan, Petkov

## Project overview 
This project implements a bookstore management system using Java with proper encapsulation,
immutability, and testing. The system demonstrates the trade-offs between ArrayList and array based implementations.

## Architecture
```
    • Model Layer: Immutable Book class with validation
    • API Layer: Clean interface for bookstore operations
    • Implementation Layer: ArrayList-based with defensive copying
    • Utils Layer: Array manipulation utilities for comparison
    • Test Layer: Comprehensive JUnit 5 tests
```

## Clone and Run instructions
``` bash
# Clone and navigate to project
cd bookstore-solution

# Build and test
./runme.sh

# Or manually:
mvn clean compile
mvn test
mvn javadoc:javadoc
```

## API usage examples
``` java
// Create bookstore
BookstoreAPI store = new BookstoreArrayList();

// Add books
Book book1 = new Book("9780123456789", "Java Programming", "John Doe", 49.99, 2023);
store.add(book1);

// Search
List<Book> javaBooks = store.findByTitle("Java");
Book found = store.findByIsbn("9780123456789");

// Analytics
double totalValue = store.inventoryValue();
Book mostExpensive = store.getMostExpensive();
```

## Performance characteristics
- Add: O(n): Due to duplicate checking 
- Search: O(n): Linear search through ArrayList
- Remove: O(n): Search + removal 
- Memory: Dynamic allocation with ArrayList

## Design decisions 
1. Immutability: Book class is immutable for thread safety
2. Defensive Copying: All returned collections are copies
3. Interface Segregation: Clean API contract
4. Validation: Comprehensive input validation

## Reflection answers
### 7.1 Data Structure Analysis
### 7.2 Design Patterns
#### Immutability Benefits
_List five specific benefits of making Book immutable. How would your API change if Book was mutable? What bugs might arise?_

A benefit of making Book immutable is that it automatically incorporates thread-safety, allowing book objects to be read without being changed across multiple threads and avoid concurrency issues. Additionally, it supports defensive design ensuring that instances of Book objects are safe to share, reuse and memorize, protecting sensitive data from unauthorized access. Immutability also guarantees predictable hashing and equality, ensuring an object’s equals() and hashCode() stay consistent as its fields remain unchanged. By keeping Book mutable any instances used for caching or memoizing will remain reliable and safe, as the internal state of the object will remain consistent through its lifetime. Lastly, since modifications won’t affect the in-memory state of objects, any snapshots taken of the database will remain reliable and consistent.

By changing Book to mutable object, our API needs to expose setter/builder methods to enable valid modifications. Additionally, pre-conditions and post-conditions need to be documented to outline how objects are meant to keep their legal states and potentially introduce version fields to track changes over time.

Potential bugs that might arise from making Book mutable are stale cache entries, broken hash-based collections, TOCTOU (Time-of-Check to Time-of-Use) validation gaps, and visibility races in multi-threaded reads.

#### Defensive Copying
_Explain why returning new ArrayList<>(internalList) is crucial. Provide a code example showing what could go wrong without it._

In *BookstoreArrayList.java* the getAllBooks() method is crucial in implementing defensive copying, ensuring that internal collections are not referenced and internal data remains secure. 

For instance, the following code demonstrates how without such measures your code is vulnerable to modification, corruption and deletion 

```java 
// BookstoreArrayList.java
public List<Book> getAllBooks() {
    return inventory;
}

// Externally Accessed
BookstoreArrayList bookstore = new BookstoreArrayList();
List<Book> external = bookstore.getAllBooks();
external.clear();
```

#### Interface Segregation
_Should BookstoreAPI be split into multiple interfaces (e.g., SearchableBookstore, MutableBookstore)? Discuss pros and cons_

Pros
- Each interface is smaller and built to serve a single purpose
- Allows external services to access the read-only functions (ex. Searching books)
- Easier to enforce certain permissions (ex. UIs can search books, not modify them)
- Easier to test each interface's functionality

Cons
- More to manage and navigate
- Related operations may end up scattered across interfaces
- Can be considered over-engineered for a relatively smaller codebases
- Higher maintenance If changes occur, there’s more to parts to modify


### 7.3 Scalability Considerations
### 7.4 Testing Philosophy
