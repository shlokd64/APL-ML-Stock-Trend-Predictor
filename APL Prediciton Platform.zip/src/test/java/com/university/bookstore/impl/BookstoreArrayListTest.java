package com.university.bookstore.impl;

import com.university.bookstore.model.Book;
import org.junit.jupiter.api.*;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for BookstoreArrayList implementation.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DisplayName("BookstoreArrayList Tests")
class BookstoreArrayListTest {
    private BookstoreArrayList bookstore;
    private Book book1, book2, book3, book4, book5;

    @BeforeEach
    void setUp() {
        bookstore = new BookstoreArrayList();

        book1 = new Book("7583497892992", "An Introduction to Higher Anatomy", "Tim Stoker", 50.99, 2000);
        book2 = new Book("5748395749298", "The Tale of a Field Hospital", "Alice Toner", 24.99, 1955);
        book3 = new Book("5843973234894", "The Bone Turner's Tale", "Gerard Key", 49.99, 2015);
        book4 = new Book("9274839478394", "Catalogue of The Trapped Dead", "Martin Blackwood", 64.50, 2006);
        book5 = new Book("7689679283437", "Ex Altiora", "Alice Toner", 19.99, 1955);
    }

    @Test
    @Order(1)
    @DisplayName("Should create empty store")
    void testEmptyStore() {
        assertEquals(0, bookstore.size());
        assertEquals(0, bookstore.findByTitle("the").size());
        assertEquals(0, bookstore.findByAuthor("Key").size());
        assertEquals(0, bookstore.findByPriceRange(0.00,40.00).size());
        assertEquals(0, bookstore.findByYear(2000).size());
        assertEquals(0.0, bookstore.inventoryValue(), 0.001);
        assertNull(bookstore.getMostExpensive());
        assertNull(bookstore.getMostRecent());
    }

    @Test
    @Order(2)
    @DisplayName("Should add a single book")
    void testAddSingleBook() {
        assertTrue(bookstore.add(book1));
        assertEquals(1, bookstore.size());
        assertEquals(book1, bookstore.findByIsbn(book1.getIsbn()));
    }

    @Test
    @Order(3)
    @DisplayName("Should not add duplicate ISBNs")
    void testNoDuplicateISBNs() {
        assertTrue(bookstore.add(book1));   // expected to return true

        Book duplicate = new Book(book1.getIsbn(), "Title", "Author", 1.00, 2025);  // duplicate entry
        assertFalse(bookstore.add(duplicate));  // expected to fail to add

        assertEquals(1, bookstore.size());  // expected to not add (remain 1)
        assertEquals("An Introduction to Higher Anatomy", bookstore.findByIsbn(book1.getIsbn()).getTitle()); // expected to be book 1
    }

    @Test
    @Order(4)
    @DisplayName("Should find books by ISBN")
    void testFindByIsbn() {
        bookstore.add(book1);
        bookstore.add(book2);

        assertEquals(book1, bookstore.findByIsbn(book1.getIsbn()));
        assertEquals(book2, bookstore.findByIsbn(book2.getIsbn()));
        assertNull(bookstore.findByIsbn("1111111111111111111"));
        assertNull(bookstore.findByIsbn(null));
    }

    @Test
    @Order(5)
    @DisplayName("Should remove book by ISBN")
    void testRemoveByIsbn() {
        bookstore.add(book1);
        bookstore.add(book2);

        assertTrue(bookstore.removeByIsbn(book1.getIsbn()));
        assertEquals(1, bookstore.size());
        assertNull(bookstore.findByIsbn(book1.getIsbn()));
        assertNotNull(bookstore.findByIsbn(book2.getIsbn()));
    }

    @Test
    @Order(6)
    @DisplayName("Should find books by title case insensitively and partially")
    void testFindByTitle() {
        bookstore.add(book1);
        bookstore.add(book2);
        bookstore.add(book3);

        List<Book> queryResult1 = bookstore.findByTitle("introduction");
        assertEquals(1, queryResult1.size());
        assertTrue(queryResult1.contains(book1));

        List<Book> queryResult2 = bookstore.findByTitle("FIELD");
        assertEquals(1, queryResult2.size());
        assertTrue(queryResult2.contains(book2));

        List<Book> queryResult3 = bookstore.findByTitle("The");
        assertEquals(2, queryResult3.size());
        assertTrue(queryResult3.contains(book2));
        assertTrue(queryResult3.contains(book3));

        assertEquals(0, bookstore.findByTitle(null).size());
        assertEquals(0, bookstore.findByTitle("").size());
    }

    @Test
    @Order(7)
    @DisplayName("Should find books by author case insensitively and partially")
    void testFindByAuthor() {
        bookstore.add(book1);
        bookstore.add(book2);
        bookstore.add(book5);

        List<Book> queryResult1 = bookstore.findByAuthor("tim");
        assertEquals(1, queryResult1.size());
        assertTrue(queryResult1.contains(book1));

        List<Book> queryResult2 = bookstore.findByAuthor("TONER");
        assertEquals(2, queryResult2.size());
        assertTrue(queryResult2.contains(book2));
        assertTrue(queryResult2.contains(book5));

        assertEquals(0, bookstore.findByAuthor(null).size());
        assertEquals(0, bookstore.findByAuthor("").size());
    }

    @Test
    @Order(8)
    @DisplayName("Should find books by price range")
    void testFindByPriceRange() {
        bookstore.add(book1); // 50.99
        bookstore.add(book2); // 24.99
        bookstore.add(book3); // 49.99

        List<Book> inRange = bookstore.findByPriceRange(40.0, 60.0);
        assertEquals(2, inRange.size());
        assertFalse(inRange.contains(book2));

        List<Book> exact = bookstore.findByPriceRange(50.99, 50.99);
        assertEquals(1, exact.size());
        assertTrue(exact.contains(book1));
    }

    @Test
    @Order(9)
    @DisplayName("Should reject invalid price ranges")
    void testInvalidPriceRange() {
        assertThrows(IllegalArgumentException.class,
                () -> bookstore.findByPriceRange(-20.0, 20.0));

        assertThrows(IllegalArgumentException.class,
                () -> bookstore.findByPriceRange(50.0, 0.0));
    }

    @Test
    @Order(10)
    @DisplayName("Should find books by year")
    void testFindByYear() {
        bookstore.add(book1); // 2000
        bookstore.add(book2); // 1955
        bookstore.add(book5); // 1955

        List<Book> sameYear = bookstore.findByYear(1955);
        assertEquals(2, sameYear.size());
        assertTrue(sameYear.contains(book2));
        assertTrue(sameYear.contains(book5));
    }

    @Test
    @Order(11)
    @DisplayName("Should return an empty list if there are no search result matches")
    void testSearchNoResults() {
        bookstore.add(book1);

        assertEquals(0, bookstore.findByTitle("The Bone Turner's Tale").size());
        assertEquals(0, bookstore.findByAuthor("Alice Toner").size());
        assertEquals(0, bookstore.findByPriceRange(0.00,20.00).size());
        assertEquals(0, bookstore.findByYear(2006).size());
    }

    @Test
    @Order(12)
    @DisplayName("Should calculate inventory value")
    void testInventoryValue() {
        assertEquals(0.0, bookstore.inventoryValue(), 0.001);

        bookstore.add(book1);
        assertEquals(50.99, bookstore.inventoryValue(), 0.001);

        bookstore.add(book2);
        assertEquals(75.98, bookstore.inventoryValue(), 0.001);

        bookstore.add(book3); // 49.99
        assertEquals(125.97, bookstore.inventoryValue(), 0.001);
    }

    @Test
    @Order(13)
    @DisplayName("Should find most expensive book")
    void testGetMostExpensive() {
        assertNull(bookstore.getMostExpensive());

        bookstore.add(book1);
        assertEquals(book1, bookstore.getMostExpensive());

        bookstore.add(book4);
        assertEquals(book4, bookstore.getMostExpensive());
    }

    @Test
    @Order(14)
    @DisplayName("Should find most recent book")
    void testGetMostRecent() {
        assertNull(bookstore.getMostRecent());

        bookstore.add(book2);
        assertEquals(book2, bookstore.getMostRecent());

        bookstore.add(book1);
        assertEquals(book1, bookstore.getMostRecent());
    }

    @Test
    @Order(15)
    @DisplayName("Should return a defensive copy of books as a list")
    void testGetAllBooks() {
        bookstore.add(book1);
        bookstore.add(book2);

        List<Book> list1 = bookstore.getAllBooks();
        assertEquals(2, list1.size());

        list1.add(book3);

        List<Book> list2 = bookstore.getAllBooks();
        assertEquals(2, list2.size());
    }

    @Test
    @Order(16)
    @DisplayName("Should return a defensive copy of books as an array")
    void testSnapshotArray() {
        bookstore.add(book1);
        bookstore.add(book2);

        Book [] array1 = bookstore.snapshotArray();
        assertEquals(2, array1.length);

        array1[0] = (book3);

        Book [] array2 = bookstore.snapshotArray();
        assertEquals(book1, array2[0]);
        assertNotEquals(book3, array2[0]);
    }
}