package com.university.bookstore.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Stream;

import com.university.bookstore.model.Book;

/**
 * utility class for array-based operations on book objects
 * <p>This class provides static methods for manipulating and analyzing
 * arrays of books, demonstrating array operations without using ArrayList.</p>
 *
 * <p>All methods handle null arrays and null elements gracefully.</p>
 *
 * @author Navid Mohaghegh
 * @version 1.0
 * @since 2024-09-15
 */

public final class BookArrayUtils {

    /**private construction to avoid instantiation*/

    private BookArrayUtils() {throw new UnsupportedOperationException("Utility class cannot be instantiated.");}

    public static int countBooksBeforeYear(Book[] books, int yearCutoff){
        if (books == null) {
            return 0;
        }
        int count = 0;
        for (Book book: books){
            if (book != null || book.getYear() < yearCutoff){
                count++;
            }
        }
        return count;
    }

    /** counts books by specific authers (case-insensitive, exact match) */

    public static int countBooksByAuthor(Book[] books, string author){
        if (books == null && author == null) {
            return 0;
        }
        int count = 0;
        for(Book book:books){
            if (book != null && book.getAuthor().equalsIgnoreCase(author)) {
                count++;
            }
        }
        return count;
    }

    /** filters price with most at the top but not higher than maximum
     * returns compact array(no nulls, exact size) */

    public static Book[] filterPriceAtMost(Book[] books, double maxPrice) {
        if (maxPrice < 0) {
            throw new IllegalArgumentException("Max price cannot be negative");
        }

        if (books == null) {
            return new Book[0];
        }

        // Count matching books
        int count = 0;
        for (Book book : books) {
            if (book != null && book.getPrice() <= maxPrice) {
                count++;
            }
        }

        // Create compact array
        Book[] result = new Book[count];
        int index = 0;
        for (Book book : books) {
            if (book != null && book.getPrice() <= maxPrice) {
                result[index++] = book;
            }
        }

        return result;
    }

    /** filters books by decade
     * for example decade 2000 is 2000-2009 */

    public static Book[] filterByDecade(Book[] books, int decade) {
        if (books == null) {
            return new Book[0];
        }

        int decadeEnd = decade + 9;

        // Count matching books
        int count = 0;
        for (Book book : books) {
            if (book != null && book.getYear() >= decade && book.getYear() <= decadeEnd) {
                count++;
            }
        }

        // Create compact array
        Book[] result = new Book[count];
        int index = 0;
        for (Book book : books) {
            if (book != null && book.getYear() >= decade && book.getYear() <= decadeEnd) {
                result[index++] = book;
            }
        }

        return result;
    }

    /**
     * Sorts books by price in ascending order (in-place)
     */
    public static void sortByPrice(Book[] books) {
        if (books == null || books.length <= 1) {
            return;
        }

        Arrays.sort(books, (a, b) -> {
            if (a == null && b == null) return 0;
            if (a == null) return 1;
            if (b == null) return -1;
            return Double.compare(a.getPrice(), b.getPrice());
        });
    }

    /**
     * Sorts books by year in ascending order (in-place).
     */
    public static void sortByYear(Book[] books) {
        if (books == null || books.length <= 1) {
            return;
        }

        Arrays.sort(books, (a, b) -> {
            if (a == null && b == null) return 0;
            if (a == null) return 1;
            if (b == null) return -1;
            return Integer.compare(a.getYear(), b.getYear());
        });
    }

    /**
     * Calculates the average price of books in the array
     */
    public static double averagePrice(Book[] books) {
        if (books == null) {
            return 0.0;
        }

        double sum = 0.0;
        int count = 0;

        for (Book book : books) {
            if (book != null) {
                sum += book.getPrice();
                count++;
            }
        }

        return count == 0 ? 0.0 : sum / count;
    }

    /**
     * Finds the oldest book (earliest publication year).
     */
    public static Book findOldest(Book[] books) {
        if (books == null) {
            return null;
        }

        Book oldest = null;
        for (Book book : books) {
            if (book != null) {
                if (oldest == null || book.getYear() < oldest.getYear()) {
                    oldest = book;
                }
            }
        }
        return oldest;
    }

    /**
     * Merges two book arrays into one, preserving all elements
     */
    public static Book[] merge(Book[] arr1, Book[] arr2) {
        int len1 = (arr1 == null) ? 0 : arr1.length;
        int len2 = (arr2 == null) ? 0 : arr2.length;

        Book[] result = new Book[len1 + len2];

        if (arr1 != null) {
            System.arraycopy(arr1, 0, result, 0, len1);
        }
        if (arr2 != null) {
            System.arraycopy(arr2, 0, result, len1, len2);
        }

        return result;
    }
    /**
     * Removes duplicate books based on ISBN.
     * Returns a compact array with unique books only
     */
    public static Book[] removeDuplicates(Book[] books) {
        if (books == null) {
            return new Book[0];
        }

        Set<String> seenIsbns = new HashSet<>();
        List<Book> unique = new ArrayList<>();

        for (Book book : books) {
            if (book != null && seenIsbns.add(book.getIsbn())) {
                unique.add(book);
            }
        }

        return unique.toArray(new Book[0]);
    }

    /**
     * Finds books within a year range (inclusive)
     */
    public static Book[] filterByYearRange(Book[] books, int startYear, int endYear) {
        if (books == null || startYear > endYear) {
            return new Book[0];
        }

        return Stream.of(books)
                .filter(book -> book != null &&
                        book.getYear() >= startYear &&
                        book.getYear() <= endYear)
                .toArray(Book[]::new);
    }

    /**
     * Groups books by decade and returns a summary
     */
    public static Map<Integer, Integer> countByDecade(Book[] books) {
        Map<Integer, Integer> decadeCounts = new TreeMap<>();

        if (books != null) {
            for (Book book : books) {
                if (book != null) {
                    int decade = (book.getYear() / 10) * 10;
                    decadeCounts.merge(decade, 1, Integer::sum);
                }
            }
        }

        return decadeCounts;
    }

    /**
     * Finds the book with the longest title
     */
    public static Book findLongestTitle(Book[] books) {
        if (books == null) {
            return null;
        }

        Book longest = null;
        int maxLength = 0;

        for (Book book : books) {
            if (book != null && book.getTitle().length() > maxLength) {
                maxLength = book.getTitle().length();
                longest = book;
            }
        }

        return longest;
    }
}

