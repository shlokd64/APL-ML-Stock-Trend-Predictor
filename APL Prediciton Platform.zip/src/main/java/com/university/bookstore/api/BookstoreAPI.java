package com.university.bookstore.api;
import java.util.List;
import com.university.bookstore.model.Book;

/**
 * Defines a comprehensive API for bookstore operations.
 * 
 * <p>This interface provides the contracted needed for managing a
 * inventory, including CRUD operations, search functionality, and
 * analytics.</p>
 * 
 * @author Shlok Desai
 * @version 1.0
 * @since 2025-09-29
*/
public interface BookstoreAPI {
    // Command to add a book into the inventory with diffrent ISBNs.
    boolean add(Book book);

    // Command to remove a book from the inventory using the ISBN.
    boolean removeByIsbn(String isbn);

    // Finds a book using its given ISBN and returns the book or null.
    Book findByIsbn(String isbn);

    // Searches for a book using its title (not case sensitive).
    List<Book> findByTitle(String titleQuery);

    // Searches for a book using its given author (not case sensitive).
    List<Book> findByAuthor(String authorQuery);

    // Searches for all books using a given price range.
    List<Book> findByPriceRange(double minPrice, double maxPrice);
    
    // Searches for all books in a specific year.
    List<Book> findByYear(int year);

    // Finds and returns the total number of books in the inventory.
    int size();

    // Calculates and returns the sum of all books in the inventory.
    double inventoryValue();

    // Finds and returns the most expensive book in the inventory.
    Book getMostExpensive();

    // Finds and returns the most recent book published.
    Book getMostRecent();

    /**
     * Creates a copy of the inventory as an array.
     * Changes to this array will not effect the inventory.
     */
    Book[] snapshotArray();

    // Gets all books in the inventory, then returns them as a list copy.
    List<Book> getAllBooks();
}