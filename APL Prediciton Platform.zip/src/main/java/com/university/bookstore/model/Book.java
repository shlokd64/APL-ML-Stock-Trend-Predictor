package com.university.bookstore.model;

import java.time.Year;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * Represents an immutable book in the bookstore inventory.
 * Books are uniquely identified by their ISBN.
 *
 * <p>This class is immutable and thread-safe. All fields are validated
 * during construction to ensure data integrity.</p>
 *
 * @author Bhagya Vithanage
 * @version 1.0
 * @since 2025-09-17
 */

public final class Book implements Comparable<Book> {

    private static final Pattern ISBN_13_PATTERN = Pattern.compile("^\\d{13}$");
    private static final Pattern ISBN_10_PATTERN = Pattern.compile("^\\d{9}[\\dX]$");
    private static final int MIN_YEAR = 1450; //The year the printing press was first established.
    private final String isbn;
    private final String title;
    private final String author;
    private final double price;
    private final int year;

    /**
     * Creates a new Book with comprehensive validation.
     *
     * @param isbn   The Book's ISBN (either 10 or 13 digits long, depending on whether it's newer or older respectively).
     * @param title  The Book's title (non-null, non-blank).
     * @param author The Book's primary author (non-null, non-blank).
     * @param price  The Book's price (non-negative).
     * @param year   The Book's publication year (from 1450 to the current year's succeeding year).
     * @throws IllegalArgumentException If any of the above parameters are invalid.
     * @throws NullPointerException     If any of the above parameters are null.
     */

    public Book(String isbn, String title, String author, double price, int year) {
        this.isbn = validateISBN(isbn);
        this.title = validateStringField(title, "Title");
        this.author = validateStringField(author, "Author");
        this.price = validatePrice(price);
        this.year = validateYear(year);
    }

    private String validateISBN(String isbn) {
        if (isbn == null) {throw new NullPointerException("The ISBN cannot be null.");}
        String cleaned = isbn.replaceAll("-", "").trim();
        if (!ISBN_10_PATTERN.matcher(cleaned).matches() && !ISBN_13_PATTERN.matcher(cleaned).matches()) {
            throw new IllegalArgumentException("The ISBN must be either 10 or 13 digits long.");
        }
        return cleaned;
    }

    private String validateStringField(String value, String fieldName) {
        if (value == null) {throw new NullPointerException("The " + fieldName + " cannot be null.");}
        if (value.trim().isEmpty()) {throw new IllegalArgumentException("The " + fieldName + " cannot be blank.");}
        return value.trim();
    }

    private double validatePrice(double price) {
        if (price < 0.0) {throw new IllegalArgumentException("The price cannot be negative, but received: " + price);}
        if (Double.isNaN(price) || Double.isInfinite(price)) {throw new IllegalArgumentException("The price must be a valid number, but received: " + price);}
        return price;
    }

    private int validateYear(int year) {
        int currentYear = Year.now().getValue();
        if (year < MIN_YEAR || year > currentYear + 1) {
            throw new IllegalArgumentException(String.format("The publication year must be between 1450-%d, but received: %d", currentYear + 1, year));
        }
        return year;
    }

    /**
     * Gets the Book's ISBN.
     * @return the ISBN (10 or 13 digits).
     */
    public String getIsbn() {return isbn;}

    /**
     * Gets the Book's title.
     * @return the title.
     */
    public String getTitle() {return title;}

    /**
     * Gets the Book's author.
     * @return the author.
     */
    public String getAuthor() {return author;}

    /**
     * Gets the Book's price.
     * @return the price.
     */
    public double getPrice() {return price;}

    /**
     * Gets the Book's publication year (from 1450 to the current year's succeeding one).
     * @return the year.
     */
    public int getYear() {return year;}

    /**
     * Compares the Book with another Book based on their titles (alphabetical order).
     *
     * @param other The other Book.
     * @return Negative whether the other Book has precedence over the current Book, positive if not, or 0 if equal.
     */
    @Override
    public int compareTo(Book other) {
        if (other == null) {throw new NullPointerException("Cannot compare to a null Book.");}
        return this.title.compareToIgnoreCase(other.title);
    }

    /**
     * Checks if this Book is equal to another object (i.e. same ISBN).
     *
     * @param obj The other object.
     * @return Return true whether both objects have the same ISBN, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {return true;}
        if (!(obj instanceof Book)) {return false;}
        Book other = (Book) obj;
        return isbn.equals(other.isbn);
    }

    /**
     * Generates hash code based on ISBN.
     *
     * @return hash code.
     */
    @Override
    public int hashCode() {return Objects.hash(isbn);}

    /**
     * Returns a human-readable string representation of the Book.
     *
     * @return formatted string with book details.
     */
    @Override
    public String toString() {
        return String.format("Book[ISBN=%s, Title='%s', Author='%s', Price=$%.2f, Year=%d]", isbn, author, price, year);
    }
}